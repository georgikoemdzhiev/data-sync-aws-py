import boto3

ec2 = boto3.resource('ec2')

s3_bucket = 'dna-spotfire-files'
template_name = 'rig_stopgap'

lt = {
    'LaunchTemplateName': template_name,
    'Version': '$Latest'
}


def handler(event, context):

    instances = ec2.create_instances(
        LaunchTemplate=lt,
        MinCount=1,
        MaxCount=1
    )
